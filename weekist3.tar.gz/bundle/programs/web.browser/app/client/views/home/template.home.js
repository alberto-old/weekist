(function(){
Template.__checkName("Home");
Template["Home"] = new Template("Template.Home", (function() {
  var view = this;
  return [ Spacebars.include(view.lookupTemplate("NavBar")), "\n\n	", Spacebars.include(view.lookupTemplate("Promo")), "\n\n	", HTML.DIV({
    "class": "container"
  }, "\n		", HTML.DIV({
    "class": "row"
  }, "\n			", HTML.DIV({
    "class": "col-xs-8 col-sm-8 col-md-8 col-lg-8"
  }, "\n				", Spacebars.include(view.lookupTemplate("HomeContent")), "\n			"), "\n			", HTML.DIV({
    "class": "col-xs-4 col-sm-4 col-md-4 col-lg-4"
  }, "\n				", Spacebars.include(view.lookupTemplate("Login")), "\n			"), "\n		"), "\n	"), HTML.Raw("\n\n    <hr>\n	"), Spacebars.include(view.lookupTemplate("Features")), "\n\n	", Spacebars.include(view.lookupTemplate("Footer")) ];
}));

})();
