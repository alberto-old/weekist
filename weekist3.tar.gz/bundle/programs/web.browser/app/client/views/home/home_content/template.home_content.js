(function(){
Template.__checkName("HomeContent");
Template["HomeContent"] = new Template("Template.HomeContent", (function() {
  var view = this;
  return HTML.Raw('<img src="images/promo-monthly-report.png" align="middle" alt="Promo Image" class="img-responsive animation-fadeIn">');
}));

})();
