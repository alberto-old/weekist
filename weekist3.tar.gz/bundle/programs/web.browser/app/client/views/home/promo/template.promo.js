(function(){
Template.__checkName("Promo");
Template["Promo"] = new Template("Template.Promo", (function() {
  var view = this;
  return HTML.Raw('<div id="home-promo" class="page-header" style="text-align: center">\n        <h2>Easily create reports for your completed Todoist tasks</h2>\n        <h1>Start <strong>now</strong>, it\'s free!</h1>\n    </div>');
}));

})();
