(function(){
Template.__checkName("Login");
Template["Login"] = new Template("Template.Login", (function() {
  var view = this;
  return HTML.DIV({
    id: "login-form"
  }, HTML.Raw("\n        <h2><strong>Login</strong> with Todoist</h2>\n        "), HTML.FORM({
    "class": "form-horizontal"
  }, "\n            ", HTML.DIV({
    style: function() {
      return [ "display:", Spacebars.mustache(view.lookup("loginFormErrorVisibility")) ];
    },
    id: "login-alert",
    "class": "alert alert-danger col-xs-12"
  }, Blaze.View("lookup:loginFormError", function() {
    return Spacebars.mustache(view.lookup("loginFormError"));
  })), "\n            ", HTML.Raw('<div class="form-group">\n                <div class="col-xs-12">\n                    <div class="input-group">\n                        <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>\n                        <input id="login-email" type="text" name="email" class="form-control input-lg" placeholder="Todoist e-mail" required="">\n                    </div>\n                </div>\n            </div>'), "\n            ", HTML.Raw('<div class="form-group">\n                <div class="col-xs-12">\n                    <div class="input-group">\n                        <span class="input-group-addon"><i class="fa fa-asterisk"></i></span>\n                        <input id="login-password" type="password" name="password" class="form-control input-lg" placeholder="Todoist password" required="">\n                    </div>\n                </div>\n            </div>'), "\n            ", HTML.Raw('<div class="form-group form-actions">\n                <div class="col-xs-12 text-right">\n                    <button type="submit" class="btn btn-lg btn-primary" style="float: right"><i class="fa fa-sign-in"></i> Sign in</button>\n                </div>\n            </div>'), "\n        "), "\n    ");
}));

})();
