(function(){
Template.__checkName("Loading");
Template["Loading"] = new Template("Template.Loading", (function() {
  var view = this;
  return HTML.Raw('<div id="loading-wait">\n        <h2>Retrieving completed tasks...</h2>\n        <h2>Be patient, the first time it may take a while, once initialized it will be much faster.</h2>\n    </div>');
}));

})();
