(function(){
Template.__checkName("NavBar");
Template["NavBar"] = new Template("Template.NavBar", (function() {
  var view = this;
  return HTML.NAV({
    "class": "navbar navbar-default",
    role: "navigation"
  }, HTML.Raw('\n        <!-- Brand and toggle get grouped for better mobile display -->\n        <div class="navbar-header">\n            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-navbar">\n                <span class="sr-only">Toggle navigation</span>\n                <i class="fa fa-bars"></i>\n            </button>\n            <a class="navbar-brand" href="/"><img src="images/weekist_logo.png" class="img-responsive" alt="weekist logo"></a>\n        </div>\n\n        '), Blaze.If(function() {
    return Spacebars.call(view.lookup("currentUser"));
  }, function() {
    return [ "\n        ", HTML.Comment(" Collect the nav links, forms, and other content for toggling "), "\n        ", HTML.DIV({
      id: "main-navbar",
      "class": "collapse navbar-collapse"
    }, "\n            ", HTML.DIV({
      "class": "container"
    }, "\n                ", HTML.Comment(" user login menu "), "\n                ", HTML.UL({
      "class": "nav navbar-nav navbar-right"
    }, "\n                    ", HTML.LI({
      id: "navbar-refresh"
    }, "\n                        ", HTML.A({
      id: "navbar-refresh-link",
      href: "#"
    }, HTML.I({
      "class": "fa fa-refresh"
    })), "\n                    "), "\n                    ", HTML.LI({
      id: "navbar-user-dropdown",
      "class": "dropdown"
    }, "\n                        ", HTML.A({
      href: "#",
      "class": "dropdown-toggle",
      "data-toggle": "dropdown"
    }, Blaze.View("lookup:currentUser.profile.name", function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "profile", "name"));
    }), " ", HTML.B({
      "class": "caret"
    })), "\n                        ", HTML.UL({
      "class": "dropdown-menu",
      style: "width: 200px;"
    }, "\n                            ", HTML.LI(HTML.A({
      href: "#"
    }, HTML.I({
      "class": "fa fa-tasks"
    }), " Completed tasks ", HTML.SPAN({
      "class": "badge"
    }, Blaze.View("lookup:totalCompleted", function() {
      return Spacebars.mustache(view.lookup("totalCompleted"));
    })))), "\n                            ", HTML.LI(HTML.A({
      id: "logout",
      href: "/"
    }, HTML.I({
      "class": "fa fa-sign-out"
    }), " Logout")), "\n                        "), "\n                    "), "\n                "), "\n                ", HTML.Comment(" end user login menu "), "\n            "), "\n        "), "\n        ", HTML.Comment(" /.navbar-collapse "), "\n        " ];
  }), "\n    ");
}));

})();
