(function(){
Template.__checkName("FilterNotes");
Template["FilterNotes"] = new Template("Template.FilterNotes", (function() {
  var view = this;
  return HTML.Raw('<div id="filter-notes" class="form-group">\n        <label for="show-notes-checkbox">Show notes</label>\n        <input id="show-notes-checkbox" type="checkbox">\n    </div>');
}));

})();
