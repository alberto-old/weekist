(function(){
Template.__checkName("RangeSelector");
Template["RangeSelector"] = new Template("Template.RangeSelector", (function() {
  var view = this;
  return HTML.Raw('<div id="range" class="input-date-range input-group date">\n		<input id="range-start" type="text" placeholder="Start date" class="form-control">\n		<span id="range-separator" class="input-group-addon"><i class="fa fa-angle-right"></i></span>				\n		<input id="range-end" type="text" placeholder="End date" class="form-control">\n	</div>');
}));

})();
