(function(){
Template.__checkName("Reports");
Template["Reports"] = new Template("Template.Reports", (function() {
  var view = this;
  return [ Spacebars.include(view.lookupTemplate("NavBar")), "\n\n	", HTML.DIV({
    "class": "container"
  }, "\n		", HTML.DIV({
    "class": "row"
  }, "\n			", HTML.DIV({
    "class": "col-xs-3 col-sm-3 col-md-3 col-lg-3"
  }, "\n				", Spacebars.include(view.lookupTemplate("ReportType")), "	\n			"), "\n\n			", HTML.DIV({
    id: "month-selector",
    "class": "col-xs-2 col-sm-2 col-md-2 col-lg-2"
  }, "\n				", Spacebars.include(view.lookupTemplate("MonthSelector")), "\n			"), "\n\n			", HTML.DIV({
    id: "week-selector",
    "class": "col-xs-2 col-sm-2 col-md-2 col-lg-2"
  }, "\n				", Spacebars.include(view.lookupTemplate("WeekSelector")), "\n			"), "\n\n			", HTML.DIV({
    id: "range-selector",
    "class": "col-xs-3 col-sm-3 col-md-3 col-lg-3"
  }, "\n				", Spacebars.include(view.lookupTemplate("RangeSelector")), "\n			"), "\n\n			", HTML.Raw('<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">\n    			<div class="input-group">\n      				<input id="btn-generate-report" type="submit" class="btn btn-default" value="Generate Report">\n    			</div>				\n			</div>'), "\n\n		"), "\n		", HTML.DIV({
    "class": "row"
  }, "\n			", HTML.DIV({
    "class": "form-inline"
  }, "\n				", HTML.DIV({
    "class": "col-xs-3 col-sm-3 col-md-3 col-lg-3"
  }, "\n					", Spacebars.include(view.lookupTemplate("FilterLabel")), "	\n				"), "\n				\n				", Spacebars.include(view.lookupTemplate("FilterProject")), "\n				", Spacebars.include(view.lookupTemplate("FilterNotes")), "					\n			"), "\n		"), "	\n	"), HTML.Raw("\n	<hr>\n	"), Blaze.If(function() {
    return Spacebars.call(view.lookup("initialized"));
  }, function() {
    return [ "\n		", Blaze.If(function() {
      return Spacebars.call(view.lookup("reportReady"));
    }, function() {
      return [ "\n		", HTML.DIV({
        "class": "container"
      }, "\n			", Blaze._TemplateWith(function() {
        return {
          reportTitle: Spacebars.call(view.lookup("title")),
          reportItems: Spacebars.call(view.lookup("items"))
        };
      }, function() {
        return Spacebars.include(view.lookupTemplate("ReportContent"));
      }), "\n		"), "\n		" ];
    }), "\n	" ];
  }, function() {
    return [ "\n	", HTML.DIV({
      "class": "container"
    }, "\n		", Spacebars.include(view.lookupTemplate("Loading")), "\n	"), "	\n	" ];
  }), "\n\n	", Spacebars.include(view.lookupTemplate("Footer")) ];
}));

})();
