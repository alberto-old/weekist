(function(){
Template.__checkName("FilterProject");
Template["FilterProject"] = new Template("Template.FilterProject", (function() {
  var view = this;
  return HTML.DIV({
    id: "filter-project",
    "class": "form-group"
  }, HTML.Raw('\n        <label for="project-select">Project:</label>\n        '), HTML.SELECT({
    id: "project-select",
    "class": "form-control"
  }, "\n            ", HTML.Raw('<option value="all" selected="">All</option>'), "\n            ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("projects"));
  }, function() {
    return [ "\n            ", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("project_id"));
      }
    }, Blaze.View("lookup:name", function() {
      return Spacebars.mustache(view.lookup("name"));
    })), "\n            " ];
  }), "\n        "), "\n    ");
}));

})();
