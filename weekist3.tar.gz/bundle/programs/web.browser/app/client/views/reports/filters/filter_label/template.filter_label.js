(function(){
Template.__checkName("FilterLabel");
Template["FilterLabel"] = new Template("Template.FilterLabel", (function() {
  var view = this;
  return HTML.DIV({
    id: "filter-label",
    "class": "form-group"
  }, HTML.Raw('\n        <label for="label-select">Label:</label>\n        '), HTML.SELECT({
    id: "label-select",
    "class": "form-control"
  }, "\n            ", HTML.Raw('<option value="all">All</option>'), "\n            ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("labels"));
  }, function() {
    return [ "\n            ", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("label_id"));
      }
    }, Blaze.View("lookup:name", function() {
      return Spacebars.mustache(view.lookup("name"));
    })), "\n            " ];
  }), "\n        "), "\n    ");
}));

})();
