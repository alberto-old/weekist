(function(){
Template.__checkName("ReportContent");
Template["ReportContent"] = new Template("Template.ReportContent", (function() {
  var view = this;
  return HTML.DIV({
    id: "report-content-panel",
    "class": "panel panel-default"
  }, "\n		  ", HTML.DIV({
    "class": "panel-heading"
  }, "\n				", HTML.H3({
    "class": "panel-title"
  }, Blaze.View("lookup:reportTitle", function() {
    return Spacebars.mustache(view.lookup("reportTitle"));
  })), "\n		  "), "\n		  ", HTML.DIV({
    "class": "panel-body"
  }, "\n				", HTML.TABLE({
    "class": "table"
  }, "\n					", HTML.TBODY("\n						", Blaze.Each(function() {
    return Spacebars.call(view.lookup("reportItems"));
  }, function() {
    return [ "\n						", HTML.TR("\n                    		", HTML.TD({
      "class": "item-date"
    }, Blaze.View("lookup:formatDate", function() {
      return Spacebars.mustache(view.lookup("formatDate"), view.lookup("completed_date"));
    })), "\n                    		", HTML.TD({
      "class": "item-content"
    }, "\n                    			", Blaze.View("lookup:formatItem", function() {
      return Spacebars.makeRaw(Spacebars.mustache(view.lookup("formatItem"), view.lookup("content")));
    }), HTML.BR(), "\n                    			", Blaze.If(function() {
      return Spacebars.call(view.lookup("showNotes"));
    }, function() {
      return [ "\n                    				", Blaze.If(function() {
        return Spacebars.call(view.lookup("hasNotes"));
      }, function() {
        return [ "\n                    					", HTML.UL("\n                    					", Blaze.Each(function() {
          return Spacebars.call(view.lookup("notes"));
        }, function() {
          return [ "\n                    						", HTML.LI(Blaze.View("lookup:formatItem", function() {
            return Spacebars.makeRaw(Spacebars.mustache(view.lookup("formatItem"), view.lookup("content")));
          })), "\n                    					" ];
        }), "\n                    					"), "\n                    				" ];
      }), "\n                    			" ];
    }), "\n                    		"), "\n						"), "\n						" ];
  }), "\n					"), "\n				"), "\n		  "), "\n	");
}));

})();
