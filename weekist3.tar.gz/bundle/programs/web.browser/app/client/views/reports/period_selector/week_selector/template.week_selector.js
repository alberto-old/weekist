(function(){
Template.__checkName("WeekSelector");
Template["WeekSelector"] = new Template("Template.WeekSelector", (function() {
  var view = this;
  return HTML.Raw('<div class="input-group datetimepicker">\n		<input id="week-selected" type="text" placeholder="Select week" class="form-control">\n		<label for="week-selected" class="input-group-addon"><i class="fa fa-calendar"></i></label>\n	</div>');
}));

})();
