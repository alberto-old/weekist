(function(){
Template.__checkName("ReportType");
Template["ReportType"] = new Template("Template.ReportType", (function() {
  var view = this;
  return HTML.Raw('<div id="report-type" class="form-group">\n		<label id="report-type-label">Report:</label>\n		<div id="report-type" class="btn-group" data-toggle="buttons">\n			<label id="report-type-month" class="btn btn-report-type active">\n	    		<input id="report-type-month-input" type="radio" autocomplete="off" checked="">Month\n	  		</label>\n	  		<label id="report-type-week" class="btn btn-report-type">\n	    		<input id="report-type-week-input" type="radio" autocomplete="off">Week\n	  		</label>\n	  		<label id="report-type-range" class="btn btn-report-type">\n	    		<input id="report-type-range-input" type="radio" autocomplete="off">Range\n	  		</label>\n	  	</div>\n	</div>');
}));

})();
