(function(){
Template.__checkName("MonthSelector");
Template["MonthSelector"] = new Template("Template.MonthSelector", (function() {
  var view = this;
  return HTML.Raw('<div id="month-selected-input-group" class="input-group datetimepicker">\n		<input id="month-selected" name="monthSelected" type="text" placeholder="Select month" class="form-control">\n		<label for="month-selected" class="input-group-addon"><i class="fa fa-calendar"></i></label>\n	</div>');
}));

})();
