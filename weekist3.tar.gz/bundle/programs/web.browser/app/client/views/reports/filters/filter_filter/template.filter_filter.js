(function(){
Template.__checkName("FilterFilter");
Template["FilterFilter"] = new Template("Template.FilterFilter", (function() {
  var view = this;
  return HTML.DIV({
    id: "filter-filter",
    "class": "form-group"
  }, HTML.Raw('\n        <label for="filter-select">Filter:</label>\n        '), HTML.SELECT({
    id: "filter-select",
    "class": "form-control",
    style: "margin-left: 5px; width: 190px;"
  }, "\n            ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("filters"));
  }, function() {
    return [ "\n            ", HTML.OPTION({
      value: function() {
        return Spacebars.mustache(view.lookup("filter_id"));
      }
    }, Blaze.View("lookup:query", function() {
      return Spacebars.mustache(view.lookup("query"));
    })), "\n            " ];
  }), "\n        "), "\n    ");
}));

})();
