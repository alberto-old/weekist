(function(){
Template.__checkName("Footer");
Template["Footer"] = new Template("Template.Footer", (function() {
  var view = this;
  return HTML.FOOTER({
    "class": "footer"
  }, "\n        ", HTML.DIV({
    "class": "container"
  }, "\n            ", HTML.Raw("<!-- Footer Links -->"), "\n            ", HTML.DIV({
    "class": "row"
  }, "\n            	", HTML.DIV({
    "class": "col-xs-4 col-sm-4 col-md-4 col-lg-4"
  }, "\n            		", HTML.P("Copyright ©2015 ", HTML.Raw("<strong>bitmoon</strong>"), " - weekist ", Blaze.View("lookup:version", function() {
    return Spacebars.mustache(view.lookup("version"));
  })), "\n            	"), "            	\n            	", HTML.Raw('<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-xs-offset-5 col-sm-offset-5 col-md-offset-5 col-lg-offset-5 text-center">\n					<a href="mailto:weekist@bitmoon.com">Contact us</a>\n            	</div>'), "\n            	", HTML.Raw('<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">\n            		<a href="https://twitter.com/weekistapp"><i class="fa fa-twitter"></i></a>\n            	</div>'), "\n            "), "\n        "), "\n    ");
}));

})();
