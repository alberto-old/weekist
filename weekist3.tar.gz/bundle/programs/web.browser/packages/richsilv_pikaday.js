//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
//                                                                      //
// If you are using Chrome, open the Developer Tools and click the gear //
// icon in its lower right corner. In the General Settings panel, turn  //
// on 'Enable source maps'.                                             //
//                                                                      //
// If you are using Firefox 23, go to `about:config` and set the        //
// `devtools.debugger.source-maps-enabled` preference to true.          //
// (The preference should be on by default in Firefox 24; versions      //
// older than 23 do not support source maps.)                           //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var $ = Package.jquery.$;
var jQuery = Package.jquery.jQuery;
var moment = Package['mrt:moment'].moment;

/* Package-scope variables */
var Pikaday;

(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/richsilv:pikaday/client/pikaday.js                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
(function (hasMoment)                                                                                             // 1
{                                                                                                                 // 2
    'use strict';                                                                                                 // 3
                                                                                                                  // 4
    /**                                                                                                           // 5
     * feature detection and helper functions                                                                     // 6
     */                                                                                                           // 7
    var hasEventListeners = !!window.addEventListener,                                                            // 8
                                                                                                                  // 9
    document = window.document,                                                                                   // 10
                                                                                                                  // 11
    sto = window.setTimeout,                                                                                      // 12
                                                                                                                  // 13
    addEvent = function(el, e, callback, capture)                                                                 // 14
    {                                                                                                             // 15
        if (hasEventListeners) {                                                                                  // 16
            el.addEventListener(e, callback, !!capture);                                                          // 17
        } else {                                                                                                  // 18
            el.attachEvent('on' + e, callback);                                                                   // 19
        }                                                                                                         // 20
    },                                                                                                            // 21
                                                                                                                  // 22
    removeEvent = function(el, e, callback, capture)                                                              // 23
    {                                                                                                             // 24
        if (hasEventListeners) {                                                                                  // 25
            el.removeEventListener(e, callback, !!capture);                                                       // 26
        } else {                                                                                                  // 27
            el.detachEvent('on' + e, callback);                                                                   // 28
        }                                                                                                         // 29
    },                                                                                                            // 30
                                                                                                                  // 31
    fireEvent = function(el, eventName, data)                                                                     // 32
    {                                                                                                             // 33
        var ev;                                                                                                   // 34
                                                                                                                  // 35
        if (document.createEvent) {                                                                               // 36
            ev = document.createEvent('HTMLEvents');                                                              // 37
            ev.initEvent(eventName, true, false);                                                                 // 38
            ev = extend(ev, data);                                                                                // 39
            el.dispatchEvent(ev);                                                                                 // 40
        } else if (document.createEventObject) {                                                                  // 41
            ev = document.createEventObject();                                                                    // 42
            ev = extend(ev, data);                                                                                // 43
            el.fireEvent('on' + eventName, ev);                                                                   // 44
        }                                                                                                         // 45
    },                                                                                                            // 46
                                                                                                                  // 47
    trim = function(str)                                                                                          // 48
    {                                                                                                             // 49
        return str.trim ? str.trim() : str.replace(/^\s+|\s+$/g,'');                                              // 50
    },                                                                                                            // 51
                                                                                                                  // 52
    hasClass = function(el, cn)                                                                                   // 53
    {                                                                                                             // 54
        return (' ' + el.className + ' ').indexOf(' ' + cn + ' ') !== -1;                                         // 55
    },                                                                                                            // 56
                                                                                                                  // 57
    addClass = function(el, cn)                                                                                   // 58
    {                                                                                                             // 59
        if (!hasClass(el, cn)) {                                                                                  // 60
            el.className = (el.className === '') ? cn : el.className + ' ' + cn;                                  // 61
        }                                                                                                         // 62
    },                                                                                                            // 63
                                                                                                                  // 64
    removeClass = function(el, cn)                                                                                // 65
    {                                                                                                             // 66
        el.className = trim((' ' + el.className + ' ').replace(' ' + cn + ' ', ' '));                             // 67
    },                                                                                                            // 68
                                                                                                                  // 69
    isArray = function(obj)                                                                                       // 70
    {                                                                                                             // 71
        return (/Array/).test(Object.prototype.toString.call(obj));                                               // 72
    },                                                                                                            // 73
                                                                                                                  // 74
    isDate = function(obj)                                                                                        // 75
    {                                                                                                             // 76
        return (/Date/).test(Object.prototype.toString.call(obj)) && !isNaN(obj.getTime());                       // 77
    },                                                                                                            // 78
                                                                                                                  // 79
    isLeapYear = function(year)                                                                                   // 80
    {                                                                                                             // 81
        // solution by Matti Virkkunen: http://stackoverflow.com/a/4881951                                        // 82
        return year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;                                            // 83
    },                                                                                                            // 84
                                                                                                                  // 85
    getDaysInMonth = function(year, month)                                                                        // 86
    {                                                                                                             // 87
        return [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];                   // 88
    },                                                                                                            // 89
                                                                                                                  // 90
    setToStartOfDay = function(date)                                                                              // 91
    {                                                                                                             // 92
        if (isDate(date)) date.setHours(0,0,0,0);                                                                 // 93
    },                                                                                                            // 94
                                                                                                                  // 95
    compareDates = function(a,b)                                                                                  // 96
    {                                                                                                             // 97
        // weak date comparison (use setToStartOfDay(date) to ensure correct result)                              // 98
        return a.getTime() === b.getTime();                                                                       // 99
    },                                                                                                            // 100
                                                                                                                  // 101
    extend = function(to, from, overwrite)                                                                        // 102
    {                                                                                                             // 103
        var prop, hasProp;                                                                                        // 104
        for (prop in from) {                                                                                      // 105
            hasProp = to[prop] !== undefined;                                                                     // 106
            if (hasProp && typeof from[prop] === 'object' && from[prop].nodeName === undefined) {                 // 107
                if (isDate(from[prop])) {                                                                         // 108
                    if (overwrite) {                                                                              // 109
                        to[prop] = new Date(from[prop].getTime());                                                // 110
                    }                                                                                             // 111
                }                                                                                                 // 112
                else if (isArray(from[prop])) {                                                                   // 113
                    if (overwrite) {                                                                              // 114
                        to[prop] = from[prop].slice(0);                                                           // 115
                    }                                                                                             // 116
                } else {                                                                                          // 117
                    to[prop] = extend({}, from[prop], overwrite);                                                 // 118
                }                                                                                                 // 119
            } else if (overwrite || !hasProp) {                                                                   // 120
                to[prop] = from[prop];                                                                            // 121
            }                                                                                                     // 122
        }                                                                                                         // 123
        return to;                                                                                                // 124
    },                                                                                                            // 125
                                                                                                                  // 126
                                                                                                                  // 127
    /**                                                                                                           // 128
     * defaults and localisation                                                                                  // 129
     */                                                                                                           // 130
    defaults = {                                                                                                  // 131
                                                                                                                  // 132
        // bind the picker to a form field                                                                        // 133
        field: null,                                                                                              // 134
                                                                                                                  // 135
        // automatically show/hide the picker on `field` focus (default `true` if `field` is set)                 // 136
        bound: undefined,                                                                                         // 137
                                                                                                                  // 138
        // position of the datepicker, relative to the field (default to bottom & left)                           // 139
        // ('bottom' & 'left' keywords are not used, 'top' & 'right' are modifier on the bottom/left position)    // 140
        position: 'bottom left',                                                                                  // 141
                                                                                                                  // 142
        // the default output format for `.toString()` and `field` value                                          // 143
        format: 'YYYY-MM-DD',                                                                                     // 144
                                                                                                                  // 145
        // the initial date to view when first opened                                                             // 146
        defaultDate: null,                                                                                        // 147
                                                                                                                  // 148
        // make the `defaultDate` the initial selected value                                                      // 149
        setDefaultDate: false,                                                                                    // 150
                                                                                                                  // 151
        // first day of week (0: Sunday, 1: Monday etc)                                                           // 152
        firstDay: 0,                                                                                              // 153
                                                                                                                  // 154
        // the minimum/earliest date that can be selected                                                         // 155
        minDate: null,                                                                                            // 156
        // the maximum/latest date that can be selected                                                           // 157
        maxDate: null,                                                                                            // 158
                                                                                                                  // 159
        // number of years either side, or array of upper/lower range                                             // 160
        yearRange: 10,                                                                                            // 161
                                                                                                                  // 162
        // used internally (don't config outside)                                                                 // 163
        minYear: 0,                                                                                               // 164
        maxYear: 9999,                                                                                            // 165
        minMonth: undefined,                                                                                      // 166
        maxMonth: undefined,                                                                                      // 167
                                                                                                                  // 168
        isRTL: false,                                                                                             // 169
                                                                                                                  // 170
        // Additional text to append to the year in the calendar title                                            // 171
        yearSuffix: '',                                                                                           // 172
                                                                                                                  // 173
        // Render the month after year in the calendar title                                                      // 174
        showMonthAfterYear: false,                                                                                // 175
                                                                                                                  // 176
        // how many months are visible (not implemented yet)                                                      // 177
        numberOfMonths: 1,                                                                                        // 178
                                                                                                                  // 179
        // internationalization                                                                                   // 180
        i18n: {                                                                                                   // 181
            previousMonth : 'Previous Month',                                                                     // 182
            nextMonth     : 'Next Month',                                                                         // 183
            months        : ['January','February','March','April','May','June','July','August','September','October','November','December'],
            weekdays      : ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],             // 185
            weekdaysShort : ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']                                           // 186
        },                                                                                                        // 187
                                                                                                                  // 188
        // callback function                                                                                      // 189
        onSelect: null,                                                                                           // 190
        onOpen: null,                                                                                             // 191
        onClose: null,                                                                                            // 192
        onDraw: null                                                                                              // 193
    },                                                                                                            // 194
                                                                                                                  // 195
                                                                                                                  // 196
    /**                                                                                                           // 197
     * templating functions to abstract HTML rendering                                                            // 198
     */                                                                                                           // 199
    renderDayName = function(opts, day, abbr)                                                                     // 200
    {                                                                                                             // 201
        day += opts.firstDay;                                                                                     // 202
        while (day >= 7) {                                                                                        // 203
            day -= 7;                                                                                             // 204
        }                                                                                                         // 205
        return abbr ? opts.i18n.weekdaysShort[day] : opts.i18n.weekdays[day];                                     // 206
    },                                                                                                            // 207
                                                                                                                  // 208
    renderDay = function(i, isSelected, isToday, isDisabled, isEmpty)                                             // 209
    {                                                                                                             // 210
        if (isEmpty) {                                                                                            // 211
            return '<td class="is-empty"></td>';                                                                  // 212
        }                                                                                                         // 213
        var arr = [];                                                                                             // 214
        if (isDisabled) {                                                                                         // 215
            arr.push('is-disabled');                                                                              // 216
        }                                                                                                         // 217
        if (isToday) {                                                                                            // 218
            arr.push('is-today');                                                                                 // 219
        }                                                                                                         // 220
        if (isSelected) {                                                                                         // 221
            arr.push('is-selected');                                                                              // 222
        }                                                                                                         // 223
        return '<td data-day="' + i + '" class="' + arr.join(' ') + '"><button class="pika-button" type="button">' + i + '</button>' + '</td>';
    },                                                                                                            // 225
                                                                                                                  // 226
    renderRow = function(days, isRTL)                                                                             // 227
    {                                                                                                             // 228
        return '<tr>' + (isRTL ? days.reverse() : days).join('') + '</tr>';                                       // 229
    },                                                                                                            // 230
                                                                                                                  // 231
    renderBody = function(rows)                                                                                   // 232
    {                                                                                                             // 233
        return '<tbody>' + rows.join('') + '</tbody>';                                                            // 234
    },                                                                                                            // 235
                                                                                                                  // 236
    renderHead = function(opts)                                                                                   // 237
    {                                                                                                             // 238
        var i, arr = [];                                                                                          // 239
        for (i = 0; i < 7; i++) {                                                                                 // 240
            arr.push('<th scope="col"><abbr title="' + renderDayName(opts, i) + '">' + renderDayName(opts, i, true) + '</abbr></th>');
        }                                                                                                         // 242
        return '<thead>' + (opts.isRTL ? arr.reverse() : arr).join('') + '</thead>';                              // 243
    },                                                                                                            // 244
                                                                                                                  // 245
    renderTitle = function(instance)                                                                              // 246
    {                                                                                                             // 247
        var i, j, arr,                                                                                            // 248
            opts = instance._o,                                                                                   // 249
            month = instance._m,                                                                                  // 250
            year  = instance._y,                                                                                  // 251
            isMinYear = year === opts.minYear,                                                                    // 252
            isMaxYear = year === opts.maxYear,                                                                    // 253
            html = '<div class="pika-title">',                                                                    // 254
            monthHtml,                                                                                            // 255
            yearHtml,                                                                                             // 256
            prev = true,                                                                                          // 257
            next = true;                                                                                          // 258
                                                                                                                  // 259
        for (arr = [], i = 0; i < 12; i++) {                                                                      // 260
            arr.push('<option value="' + i + '"' +                                                                // 261
                (i === month ? ' selected': '') +                                                                 // 262
                ((isMinYear && i < opts.minMonth) || (isMaxYear && i > opts.maxMonth) ? 'disabled' : '') + '>' +  // 263
                opts.i18n.months[i] + '</option>');                                                               // 264
        }                                                                                                         // 265
        monthHtml = '<div class="pika-label">' + opts.i18n.months[month] + '<select class="pika-select pika-select-month">' + arr.join('') + '</select></div>';
                                                                                                                  // 267
        if (isArray(opts.yearRange)) {                                                                            // 268
            i = opts.yearRange[0];                                                                                // 269
            j = opts.yearRange[1] + 1;                                                                            // 270
        } else {                                                                                                  // 271
            i = year - opts.yearRange;                                                                            // 272
            j = 1 + year + opts.yearRange;                                                                        // 273
        }                                                                                                         // 274
                                                                                                                  // 275
        for (arr = []; i < j && i <= opts.maxYear; i++) {                                                         // 276
            if (i >= opts.minYear) {                                                                              // 277
                arr.push('<option value="' + i + '"' + (i === year ? ' selected': '') + '>' + (i) + '</option>'); // 278
            }                                                                                                     // 279
        }                                                                                                         // 280
        yearHtml = '<div class="pika-label">' + year + opts.yearSuffix + '<select class="pika-select pika-select-year">' + arr.join('') + '</select></div>';
                                                                                                                  // 282
        if (opts.showMonthAfterYear) {                                                                            // 283
            html += yearHtml + monthHtml;                                                                         // 284
        } else {                                                                                                  // 285
            html += monthHtml + yearHtml;                                                                         // 286
        }                                                                                                         // 287
                                                                                                                  // 288
        if (isMinYear && (month === 0 || opts.minMonth >= month)) {                                               // 289
            prev = false;                                                                                         // 290
        }                                                                                                         // 291
                                                                                                                  // 292
        if (isMaxYear && (month === 11 || opts.maxMonth <= month)) {                                              // 293
            next = false;                                                                                         // 294
        }                                                                                                         // 295
                                                                                                                  // 296
        html += '<button class="pika-prev' + (prev ? '' : ' is-disabled') + '" type="button">' + opts.i18n.previousMonth + '</button>';
        html += '<button class="pika-next' + (next ? '' : ' is-disabled') + '" type="button">' + opts.i18n.nextMonth + '</button>';
                                                                                                                  // 299
        return html += '</div>';                                                                                  // 300
    },                                                                                                            // 301
                                                                                                                  // 302
    renderTable = function(opts, data)                                                                            // 303
    {                                                                                                             // 304
        return '<table cellpadding="0" cellspacing="0" class="pika-table">' + renderHead(opts) + renderBody(data) + '</table>';
    },                                                                                                            // 306
                                                                                                                  // 307
                                                                                                                  // 308
    /**                                                                                                           // 309
     * Pikaday constructor                                                                                        // 310
     */                                                                                                           // 311
    Pikaday = function(options)                                                                                   // 312
    {                                                                                                             // 313
        var self = this,                                                                                          // 314
            opts = self.config(options);                                                                          // 315
                                                                                                                  // 316
        self._onMouseDown = function(e)                                                                           // 317
        {                                                                                                         // 318
            if (!self._v) {                                                                                       // 319
                return;                                                                                           // 320
            }                                                                                                     // 321
            e = e || window.event;                                                                                // 322
            var target = e.target || e.srcElement;                                                                // 323
            if (!target) {                                                                                        // 324
                return;                                                                                           // 325
            }                                                                                                     // 326
                                                                                                                  // 327
            if (!hasClass(target, 'is-disabled')) {                                                               // 328
                if (hasClass(target, 'pika-button') && !hasClass(target, 'is-empty')) {                           // 329
                    self.setDate(new Date(self._y, self._m, parseInt(target.innerHTML, 10)));                     // 330
                    if (opts.bound) {                                                                             // 331
                        sto(function() {                                                                          // 332
                            self.hide();                                                                          // 333
                        }, 100);                                                                                  // 334
                    }                                                                                             // 335
                    return;                                                                                       // 336
                }                                                                                                 // 337
                else if (hasClass(target, 'pika-prev')) {                                                         // 338
                    self.prevMonth();                                                                             // 339
                }                                                                                                 // 340
                else if (hasClass(target, 'pika-next')) {                                                         // 341
                    self.nextMonth();                                                                             // 342
                }                                                                                                 // 343
            }                                                                                                     // 344
            if (!hasClass(target, 'pika-select')) {                                                               // 345
                if (e.preventDefault) {                                                                           // 346
                    e.preventDefault();                                                                           // 347
                } else {                                                                                          // 348
                    e.returnValue = false;                                                                        // 349
                    return false;                                                                                 // 350
                }                                                                                                 // 351
            } else {                                                                                              // 352
                self._c = true;                                                                                   // 353
            }                                                                                                     // 354
        };                                                                                                        // 355
                                                                                                                  // 356
        self._onChange = function(e)                                                                              // 357
        {                                                                                                         // 358
            e = e || window.event;                                                                                // 359
            var target = e.target || e.srcElement;                                                                // 360
            if (!target) {                                                                                        // 361
                return;                                                                                           // 362
            }                                                                                                     // 363
            if (hasClass(target, 'pika-select-month')) {                                                          // 364
                self.gotoMonth(target.value);                                                                     // 365
            }                                                                                                     // 366
            else if (hasClass(target, 'pika-select-year')) {                                                      // 367
                self.gotoYear(target.value);                                                                      // 368
            }                                                                                                     // 369
        };                                                                                                        // 370
                                                                                                                  // 371
        self._onInputChange = function(e)                                                                         // 372
        {                                                                                                         // 373
            var date;                                                                                             // 374
                                                                                                                  // 375
            if (e.firedBy === self) {                                                                             // 376
                return;                                                                                           // 377
            }                                                                                                     // 378
            if (hasMoment) {                                                                                      // 379
                date = moment(opts.field.value, opts.format);                                                     // 380
                date = (date && date.isValid()) ? date.toDate() : null;                                           // 381
            }                                                                                                     // 382
            else {                                                                                                // 383
                date = new Date(Date.parse(opts.field.value));                                                    // 384
            }                                                                                                     // 385
            self.setDate(isDate(date) ? date : null);                                                             // 386
            if (!self._v) {                                                                                       // 387
                self.show();                                                                                      // 388
            }                                                                                                     // 389
        };                                                                                                        // 390
                                                                                                                  // 391
        self._onInputFocus = function()                                                                           // 392
        {                                                                                                         // 393
            self.show();                                                                                          // 394
        };                                                                                                        // 395
                                                                                                                  // 396
        self._onInputClick = function()                                                                           // 397
        {                                                                                                         // 398
            self.show();                                                                                          // 399
        };                                                                                                        // 400
                                                                                                                  // 401
        self._onInputBlur = function()                                                                            // 402
        {                                                                                                         // 403
            if (!self._c) {                                                                                       // 404
                self._b = sto(function() {                                                                        // 405
                    self.hide();                                                                                  // 406
                }, 50);                                                                                           // 407
            }                                                                                                     // 408
            self._c = false;                                                                                      // 409
        };                                                                                                        // 410
                                                                                                                  // 411
        self._onClick = function(e)                                                                               // 412
        {                                                                                                         // 413
            e = e || window.event;                                                                                // 414
            var target = e.target || e.srcElement,                                                                // 415
                pEl = target;                                                                                     // 416
            if (!target) {                                                                                        // 417
                return;                                                                                           // 418
            }                                                                                                     // 419
            if (!hasEventListeners && hasClass(target, 'pika-select')) {                                          // 420
                if (!target.onchange) {                                                                           // 421
                    target.setAttribute('onchange', 'return;');                                                   // 422
                    addEvent(target, 'change', self._onChange);                                                   // 423
                }                                                                                                 // 424
            }                                                                                                     // 425
            do {                                                                                                  // 426
                if (hasClass(pEl, 'pika-single')) {                                                               // 427
                    return;                                                                                       // 428
                }                                                                                                 // 429
            }                                                                                                     // 430
            while ((pEl = pEl.parentNode));                                                                       // 431
            if (self._v && target !== opts.trigger) {                                                             // 432
                self.hide();                                                                                      // 433
            }                                                                                                     // 434
        };                                                                                                        // 435
                                                                                                                  // 436
        self.el = document.createElement('div');                                                                  // 437
        self.el.className = 'pika-single' + (opts.isRTL ? ' is-rtl' : '');                                        // 438
                                                                                                                  // 439
        addEvent(self.el, 'mousedown', self._onMouseDown, true);                                                  // 440
        addEvent(self.el, 'change', self._onChange);                                                              // 441
                                                                                                                  // 442
        if (opts.field) {                                                                                         // 443
            if (opts.bound) {                                                                                     // 444
                document.body.appendChild(self.el);                                                               // 445
            } else {                                                                                              // 446
                opts.field.parentNode.insertBefore(self.el, opts.field.nextSibling);                              // 447
            }                                                                                                     // 448
            addEvent(opts.field, 'change', self._onInputChange);                                                  // 449
                                                                                                                  // 450
            if (!opts.defaultDate) {                                                                              // 451
                if (hasMoment && opts.field.value) {                                                              // 452
                    opts.defaultDate = moment(opts.field.value, opts.format).toDate();                            // 453
                } else {                                                                                          // 454
                    opts.defaultDate = new Date(Date.parse(opts.field.value));                                    // 455
                }                                                                                                 // 456
                opts.setDefaultDate = true;                                                                       // 457
            }                                                                                                     // 458
        }                                                                                                         // 459
                                                                                                                  // 460
        var defDate = opts.defaultDate;                                                                           // 461
                                                                                                                  // 462
        if (isDate(defDate)) {                                                                                    // 463
            if (opts.setDefaultDate) {                                                                            // 464
                self.setDate(defDate, true);                                                                      // 465
            } else {                                                                                              // 466
                self.gotoDate(defDate);                                                                           // 467
            }                                                                                                     // 468
        } else {                                                                                                  // 469
            self.gotoDate(new Date());                                                                            // 470
        }                                                                                                         // 471
                                                                                                                  // 472
        if (opts.bound) {                                                                                         // 473
            this.hide();                                                                                          // 474
            self.el.className += ' is-bound';                                                                     // 475
            addEvent(opts.trigger, 'click', self._onInputClick);                                                  // 476
            addEvent(opts.trigger, 'focus', self._onInputFocus);                                                  // 477
            addEvent(opts.trigger, 'blur', self._onInputBlur);                                                    // 478
        } else {                                                                                                  // 479
            this.show();                                                                                          // 480
        }                                                                                                         // 481
                                                                                                                  // 482
    };                                                                                                            // 483
                                                                                                                  // 484
                                                                                                                  // 485
    /**                                                                                                           // 486
     * public Pikaday API                                                                                         // 487
     */                                                                                                           // 488
    Pikaday.prototype = {                                                                                         // 489
                                                                                                                  // 490
                                                                                                                  // 491
        /**                                                                                                       // 492
         * configure functionality                                                                                // 493
         */                                                                                                       // 494
        config: function(options)                                                                                 // 495
        {                                                                                                         // 496
            if (!this._o) {                                                                                       // 497
                this._o = extend({}, defaults, true);                                                             // 498
            }                                                                                                     // 499
                                                                                                                  // 500
            var opts = extend(this._o, options, true);                                                            // 501
                                                                                                                  // 502
            opts.isRTL = !!opts.isRTL;                                                                            // 503
                                                                                                                  // 504
            opts.field = (opts.field && opts.field.nodeName) ? opts.field : null;                                 // 505
                                                                                                                  // 506
            opts.bound = !!(opts.bound !== undefined ? opts.field && opts.bound : opts.field);                    // 507
                                                                                                                  // 508
            opts.trigger = (opts.trigger && opts.trigger.nodeName) ? opts.trigger : opts.field;                   // 509
                                                                                                                  // 510
            var nom = parseInt(opts.numberOfMonths, 10) || 1;                                                     // 511
            opts.numberOfMonths = nom > 4 ? 4 : nom;                                                              // 512
                                                                                                                  // 513
            if (!isDate(opts.minDate)) {                                                                          // 514
                opts.minDate = false;                                                                             // 515
            }                                                                                                     // 516
            if (!isDate(opts.maxDate)) {                                                                          // 517
                opts.maxDate = false;                                                                             // 518
            }                                                                                                     // 519
            if ((opts.minDate && opts.maxDate) && opts.maxDate < opts.minDate) {                                  // 520
                opts.maxDate = opts.minDate = false;                                                              // 521
            }                                                                                                     // 522
            if (opts.minDate) {                                                                                   // 523
                setToStartOfDay(opts.minDate);                                                                    // 524
                opts.minYear  = opts.minDate.getFullYear();                                                       // 525
                opts.minMonth = opts.minDate.getMonth();                                                          // 526
            }                                                                                                     // 527
            if (opts.maxDate) {                                                                                   // 528
                setToStartOfDay(opts.maxDate);                                                                    // 529
                opts.maxYear  = opts.maxDate.getFullYear();                                                       // 530
                opts.maxMonth = opts.maxDate.getMonth();                                                          // 531
            }                                                                                                     // 532
                                                                                                                  // 533
            if (isArray(opts.yearRange)) {                                                                        // 534
                var fallback = new Date().getFullYear() - 10;                                                     // 535
                opts.yearRange[0] = parseInt(opts.yearRange[0], 10) || fallback;                                  // 536
                opts.yearRange[1] = parseInt(opts.yearRange[1], 10) || fallback;                                  // 537
            } else {                                                                                              // 538
                opts.yearRange = Math.abs(parseInt(opts.yearRange, 10)) || defaults.yearRange;                    // 539
                if (opts.yearRange > 100) {                                                                       // 540
                    opts.yearRange = 100;                                                                         // 541
                }                                                                                                 // 542
            }                                                                                                     // 543
                                                                                                                  // 544
            return opts;                                                                                          // 545
        },                                                                                                        // 546
                                                                                                                  // 547
        /**                                                                                                       // 548
         * return a formatted string of the current selection (using Moment.js if available)                      // 549
         */                                                                                                       // 550
        toString: function(format)                                                                                // 551
        {                                                                                                         // 552
            return !isDate(this._d) ? '' : hasMoment ? moment(this._d).format(format || this._o.format) : this._d.toDateString();
        },                                                                                                        // 554
                                                                                                                  // 555
        /**                                                                                                       // 556
         * return a Moment.js object of the current selection (if available)                                      // 557
         */                                                                                                       // 558
        getMoment: function()                                                                                     // 559
        {                                                                                                         // 560
            return hasMoment ? moment(this._d) : null;                                                            // 561
        },                                                                                                        // 562
                                                                                                                  // 563
        /**                                                                                                       // 564
         * set the current selection from a Moment.js object (if available)                                       // 565
         */                                                                                                       // 566
        setMoment: function(date, preventOnSelect)                                                                // 567
        {                                                                                                         // 568
            if (hasMoment && moment.isMoment(date)) {                                                             // 569
                this.setDate(date.toDate(), preventOnSelect);                                                     // 570
            }                                                                                                     // 571
        },                                                                                                        // 572
                                                                                                                  // 573
        /**                                                                                                       // 574
         * return a Date object of the current selection                                                          // 575
         */                                                                                                       // 576
        getDate: function()                                                                                       // 577
        {                                                                                                         // 578
            return isDate(this._d) ? new Date(this._d.getTime()) : null;                                          // 579
        },                                                                                                        // 580
                                                                                                                  // 581
        /**                                                                                                       // 582
         * set the current selection                                                                              // 583
         */                                                                                                       // 584
        setDate: function(date, preventOnSelect)                                                                  // 585
        {                                                                                                         // 586
            if (!date) {                                                                                          // 587
                this._d = null;                                                                                   // 588
                return this.draw();                                                                               // 589
            }                                                                                                     // 590
            if (typeof date === 'string') {                                                                       // 591
                date = new Date(Date.parse(date));                                                                // 592
            }                                                                                                     // 593
            if (!isDate(date)) {                                                                                  // 594
                return;                                                                                           // 595
            }                                                                                                     // 596
                                                                                                                  // 597
            var min = this._o.minDate,                                                                            // 598
                max = this._o.maxDate;                                                                            // 599
                                                                                                                  // 600
            if (isDate(min) && date < min) {                                                                      // 601
                date = min;                                                                                       // 602
            } else if (isDate(max) && date > max) {                                                               // 603
                date = max;                                                                                       // 604
            }                                                                                                     // 605
                                                                                                                  // 606
            this._d = new Date(date.getTime());                                                                   // 607
            setToStartOfDay(this._d);                                                                             // 608
            this.gotoDate(this._d);                                                                               // 609
                                                                                                                  // 610
            if (this._o.field) {                                                                                  // 611
                this._o.field.value = this.toString();                                                            // 612
                fireEvent(this._o.field, 'change', { firedBy: this });                                            // 613
            }                                                                                                     // 614
            if (!preventOnSelect && typeof this._o.onSelect === 'function') {                                     // 615
                this._o.onSelect.call(this, this.getDate());                                                      // 616
            }                                                                                                     // 617
        },                                                                                                        // 618
                                                                                                                  // 619
        /**                                                                                                       // 620
         * change view to a specific date                                                                         // 621
         */                                                                                                       // 622
        gotoDate: function(date)                                                                                  // 623
        {                                                                                                         // 624
            if (!isDate(date)) {                                                                                  // 625
                return;                                                                                           // 626
            }                                                                                                     // 627
            this._y = date.getFullYear();                                                                         // 628
            this._m = date.getMonth();                                                                            // 629
            this.draw();                                                                                          // 630
        },                                                                                                        // 631
                                                                                                                  // 632
        gotoToday: function()                                                                                     // 633
        {                                                                                                         // 634
            this.gotoDate(new Date());                                                                            // 635
        },                                                                                                        // 636
                                                                                                                  // 637
        /**                                                                                                       // 638
         * change view to a specific month (zero-index, e.g. 0: January)                                          // 639
         */                                                                                                       // 640
        gotoMonth: function(month)                                                                                // 641
        {                                                                                                         // 642
            if (!isNaN( (month = parseInt(month, 10)) )) {                                                        // 643
                this._m = month < 0 ? 0 : month > 11 ? 11 : month;                                                // 644
                this.draw();                                                                                      // 645
            }                                                                                                     // 646
        },                                                                                                        // 647
                                                                                                                  // 648
        nextMonth: function()                                                                                     // 649
        {                                                                                                         // 650
            if (++this._m > 11) {                                                                                 // 651
                this._m = 0;                                                                                      // 652
                this._y++;                                                                                        // 653
            }                                                                                                     // 654
            this.draw();                                                                                          // 655
        },                                                                                                        // 656
                                                                                                                  // 657
        prevMonth: function()                                                                                     // 658
        {                                                                                                         // 659
            if (--this._m < 0) {                                                                                  // 660
                this._m = 11;                                                                                     // 661
                this._y--;                                                                                        // 662
            }                                                                                                     // 663
            this.draw();                                                                                          // 664
        },                                                                                                        // 665
                                                                                                                  // 666
        /**                                                                                                       // 667
         * change view to a specific full year (e.g. "2012")                                                      // 668
         */                                                                                                       // 669
        gotoYear: function(year)                                                                                  // 670
        {                                                                                                         // 671
            if (!isNaN(year)) {                                                                                   // 672
                this._y = parseInt(year, 10);                                                                     // 673
                this.draw();                                                                                      // 674
            }                                                                                                     // 675
        },                                                                                                        // 676
                                                                                                                  // 677
        /**                                                                                                       // 678
         * change the minDate                                                                                     // 679
         */                                                                                                       // 680
        setMinDate: function(value)                                                                               // 681
        {                                                                                                         // 682
            this._o.minDate = value;                                                                              // 683
        },                                                                                                        // 684
                                                                                                                  // 685
        /**                                                                                                       // 686
         * change the maxDate                                                                                     // 687
         */                                                                                                       // 688
        setMaxDate: function(value)                                                                               // 689
        {                                                                                                         // 690
            this._o.maxDate = value;                                                                              // 691
        },                                                                                                        // 692
                                                                                                                  // 693
        /**                                                                                                       // 694
         * refresh the HTML                                                                                       // 695
         */                                                                                                       // 696
        draw: function(force)                                                                                     // 697
        {                                                                                                         // 698
            if (!this._v && !force) {                                                                             // 699
                return;                                                                                           // 700
            }                                                                                                     // 701
            var opts = this._o,                                                                                   // 702
                minYear = opts.minYear,                                                                           // 703
                maxYear = opts.maxYear,                                                                           // 704
                minMonth = opts.minMonth,                                                                         // 705
                maxMonth = opts.maxMonth;                                                                         // 706
                                                                                                                  // 707
            if (this._y <= minYear) {                                                                             // 708
                this._y = minYear;                                                                                // 709
                if (!isNaN(minMonth) && this._m < minMonth) {                                                     // 710
                    this._m = minMonth;                                                                           // 711
                }                                                                                                 // 712
            }                                                                                                     // 713
            if (this._y >= maxYear) {                                                                             // 714
                this._y = maxYear;                                                                                // 715
                if (!isNaN(maxMonth) && this._m > maxMonth) {                                                     // 716
                    this._m = maxMonth;                                                                           // 717
                }                                                                                                 // 718
            }                                                                                                     // 719
                                                                                                                  // 720
            this.el.innerHTML = renderTitle(this) + this.render(this._y, this._m);                                // 721
                                                                                                                  // 722
            if (opts.bound) {                                                                                     // 723
                this.adjustPosition();                                                                            // 724
                if(opts.field.type !== 'hidden') {                                                                // 725
                    sto(function() {                                                                              // 726
                        opts.trigger.focus();                                                                     // 727
                    }, 1);                                                                                        // 728
                }                                                                                                 // 729
            }                                                                                                     // 730
                                                                                                                  // 731
            if (typeof this._o.onDraw === 'function') {                                                           // 732
                var self = this;                                                                                  // 733
                sto(function() {                                                                                  // 734
                    self._o.onDraw.call(self);                                                                    // 735
                }, 0);                                                                                            // 736
            }                                                                                                     // 737
        },                                                                                                        // 738
                                                                                                                  // 739
        adjustPosition: function()                                                                                // 740
        {                                                                                                         // 741
            var field = this._o.trigger, pEl = field,                                                             // 742
            width = this.el.offsetWidth, height = this.el.offsetHeight,                                           // 743
            viewportWidth = window.innerWidth || document.documentElement.clientWidth,                            // 744
            viewportHeight = window.innerHeight || document.documentElement.clientHeight,                         // 745
            scrollTop = window.pageYOffset || document.body.scrollTop || document.documentElement.scrollTop,      // 746
            left, top, clientRect;                                                                                // 747
                                                                                                                  // 748
            if (typeof field.getBoundingClientRect === 'function') {                                              // 749
                clientRect = field.getBoundingClientRect();                                                       // 750
                left = clientRect.left + window.pageXOffset;                                                      // 751
                top = clientRect.bottom + window.pageYOffset;                                                     // 752
            } else {                                                                                              // 753
                left = pEl.offsetLeft;                                                                            // 754
                top  = pEl.offsetTop + pEl.offsetHeight;                                                          // 755
                while((pEl = pEl.offsetParent)) {                                                                 // 756
                    left += pEl.offsetLeft;                                                                       // 757
                    top  += pEl.offsetTop;                                                                        // 758
                }                                                                                                 // 759
            }                                                                                                     // 760
                                                                                                                  // 761
            // default position is bottom & left                                                                  // 762
            if (left + width > viewportWidth ||                                                                   // 763
                (                                                                                                 // 764
                    this._o.position.indexOf('right') > -1 &&                                                     // 765
                    left - width + field.offsetWidth > 0                                                          // 766
                )                                                                                                 // 767
            ) {                                                                                                   // 768
                left = left - width + field.offsetWidth;                                                          // 769
            }                                                                                                     // 770
            if (top + height > viewportHeight + scrollTop ||                                                      // 771
                (                                                                                                 // 772
                    this._o.position.indexOf('top') > -1 &&                                                       // 773
                    top - height - field.offsetHeight > 0                                                         // 774
                )                                                                                                 // 775
            ) {                                                                                                   // 776
                top = top - height - field.offsetHeight;                                                          // 777
            }                                                                                                     // 778
            this.el.style.cssText = [                                                                             // 779
                'position: absolute',                                                                             // 780
                'left: ' + left + 'px',                                                                           // 781
                'top: ' + top + 'px'                                                                              // 782
            ].join(';');                                                                                          // 783
        },                                                                                                        // 784
                                                                                                                  // 785
        /**                                                                                                       // 786
         * render HTML for a particular month                                                                     // 787
         */                                                                                                       // 788
        render: function(year, month)                                                                             // 789
        {                                                                                                         // 790
            var opts   = this._o,                                                                                 // 791
                now    = new Date(),                                                                              // 792
                days   = getDaysInMonth(year, month),                                                             // 793
                before = new Date(year, month, 1).getDay(),                                                       // 794
                data   = [],                                                                                      // 795
                row    = [];                                                                                      // 796
            setToStartOfDay(now);                                                                                 // 797
            if (opts.firstDay > 0) {                                                                              // 798
                before -= opts.firstDay;                                                                          // 799
                if (before < 0) {                                                                                 // 800
                    before += 7;                                                                                  // 801
                }                                                                                                 // 802
            }                                                                                                     // 803
            var cells = days + before,                                                                            // 804
                after = cells;                                                                                    // 805
            while(after > 7) {                                                                                    // 806
                after -= 7;                                                                                       // 807
            }                                                                                                     // 808
            cells += 7 - after;                                                                                   // 809
            for (var i = 0, r = 0; i < cells; i++)                                                                // 810
            {                                                                                                     // 811
                var day = new Date(year, month, 1 + (i - before)),                                                // 812
                    isDisabled = (opts.minDate && day < opts.minDate) || (opts.maxDate && day > opts.maxDate),    // 813
                    isSelected = isDate(this._d) ? compareDates(day, this._d) : false,                            // 814
                    isToday = compareDates(day, now),                                                             // 815
                    isEmpty = i < before || i >= (days + before);                                                 // 816
                                                                                                                  // 817
                row.push(renderDay(1 + (i - before), isSelected, isToday, isDisabled, isEmpty));                  // 818
                                                                                                                  // 819
                if (++r === 7) {                                                                                  // 820
                    data.push(renderRow(row, opts.isRTL));                                                        // 821
                    row = [];                                                                                     // 822
                    r = 0;                                                                                        // 823
                }                                                                                                 // 824
            }                                                                                                     // 825
            return renderTable(opts, data);                                                                       // 826
        },                                                                                                        // 827
                                                                                                                  // 828
        isVisible: function()                                                                                     // 829
        {                                                                                                         // 830
            return this._v;                                                                                       // 831
        },                                                                                                        // 832
                                                                                                                  // 833
        show: function()                                                                                          // 834
        {                                                                                                         // 835
            if (!this._v) {                                                                                       // 836
                if (this._o.bound) {                                                                              // 837
                    addEvent(document, 'click', this._onClick);                                                   // 838
                }                                                                                                 // 839
                removeClass(this.el, 'is-hidden');                                                                // 840
                this._v = true;                                                                                   // 841
                this.draw();                                                                                      // 842
                if (typeof this._o.onOpen === 'function') {                                                       // 843
                    this._o.onOpen.call(this);                                                                    // 844
                }                                                                                                 // 845
            }                                                                                                     // 846
        },                                                                                                        // 847
                                                                                                                  // 848
        hide: function()                                                                                          // 849
        {                                                                                                         // 850
            var v = this._v;                                                                                      // 851
            if (v !== false) {                                                                                    // 852
                if (this._o.bound) {                                                                              // 853
                    removeEvent(document, 'click', this._onClick);                                                // 854
                }                                                                                                 // 855
                this.el.style.cssText = '';                                                                       // 856
                addClass(this.el, 'is-hidden');                                                                   // 857
                this._v = false;                                                                                  // 858
                if (v !== undefined && typeof this._o.onClose === 'function') {                                   // 859
                    this._o.onClose.call(this);                                                                   // 860
                }                                                                                                 // 861
            }                                                                                                     // 862
        },                                                                                                        // 863
                                                                                                                  // 864
        /**                                                                                                       // 865
         * GAME OVER                                                                                              // 866
         */                                                                                                       // 867
        destroy: function()                                                                                       // 868
        {                                                                                                         // 869
            this.hide();                                                                                          // 870
            removeEvent(this.el, 'mousedown', this._onMouseDown, true);                                           // 871
            removeEvent(this.el, '_onChangee', this._onChange);                                                   // 872
            if (this._o.field) {                                                                                  // 873
                removeEvent(this._o.field, 'change', this._onInputChange);                                        // 874
                if (this._o.bound) {                                                                              // 875
                    removeEvent(this._o.trigger, 'click', this._onInputClick);                                    // 876
                    removeEvent(this._o.trigger, 'focus', this._onInputFocus);                                    // 877
                    removeEvent(this._o.trigger, 'blur', this._onInputBlur);                                      // 878
                }                                                                                                 // 879
            }                                                                                                     // 880
            if (this.el.parentNode) {                                                                             // 881
                this.el.parentNode.removeChild(this.el);                                                          // 882
            }                                                                                                     // 883
        }                                                                                                         // 884
                                                                                                                  // 885
    };                                                                                                            // 886
                                                                                                                  // 887
    window.Pikaday = Pikaday;                                                                                     // 888
                                                                                                                  // 889
})(true);                                                                                                         // 890
                                                                                                                  // 891
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/richsilv:pikaday/client/export-pikaday.js                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Pikaday = this.Pikaday;                                                                                           // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['richsilv:pikaday'] = {
  Pikaday: Pikaday
};

})();
