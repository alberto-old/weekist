(function(){Meteor.methods({
	getVersion: function () {
		return "v2.0.3";
	}
});

})();
