(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:nprogress'] = {};

})();

//# sourceMappingURL=mrt_nprogress.js.map
