(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Autolinker;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/copleykj:autolinker/autolinker.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
	/**                                                                                                                   // 1
	 * @class Autolinker                                                                                                  // 2
	 * @extends Object                                                                                                    // 3
	 *                                                                                                                    // 4
	 * Utility class used to process a given string of text, and wrap the URLs, email addresses, and Twitter handles in   // 5
	 * the appropriate anchor (&lt;a&gt;) tags to turn them into links.                                                   // 6
	 *                                                                                                                    // 7
	 * Any of the configuration options may be provided in an Object (map) provided to the Autolinker constructor, which  // 8
	 * will configure how the {@link #link link()} method will process the links.                                         // 9
	 *                                                                                                                    // 10
	 * For example:                                                                                                       // 11
	 *                                                                                                                    // 12
	 *     var autolinker = new Autolinker( {                                                                             // 13
	 *         newWindow : false,                                                                                         // 14
	 *         truncate  : 30                                                                                             // 15
	 *     } );                                                                                                           // 16
	 *                                                                                                                    // 17
	 *     var html = autolinker.link( "Joe went to www.yahoo.com" );                                                     // 18
	 *     // produces: 'Joe went to <a href="http://www.yahoo.com">yahoo.com</a>'                                        // 19
	 *                                                                                                                    // 20
	 *                                                                                                                    // 21
	 * The {@link #static-link static link()} method may also be used to inline options into a single call, which may     // 22
	 * be more convenient for one-off uses. For example:                                                                  // 23
	 *                                                                                                                    // 24
	 *     var html = Autolinker.link( "Joe went to www.yahoo.com", {                                                     // 25
	 *         newWindow : false,                                                                                         // 26
	 *         truncate  : 30                                                                                             // 27
	 *     } );                                                                                                           // 28
	 *     // produces: 'Joe went to <a href="http://www.yahoo.com">yahoo.com</a>'                                        // 29
	 *                                                                                                                    // 30
	 * @constructor                                                                                                       // 31
	 * @param {Object} [config] The configuration options for the Autolinker instance, specified in an Object (map).      // 32
	 */                                                                                                                   // 33
    Autolinker = function( cfg ) {                                                                                     // 34
		cfg = cfg || {};                                                                                                     // 35
                                                                                                                       // 36
		// Assign the properties of `cfg` onto the Autolinker instance                                                       // 37
		for( var prop in cfg )                                                                                               // 38
			if( cfg.hasOwnProperty( prop ) ) this[ prop ] = cfg[ prop ];                                                        // 39
	};                                                                                                                    // 40
                                                                                                                       // 41
                                                                                                                       // 42
	Autolinker.prototype = {                                                                                              // 43
		constructor : Autolinker,  // fix constructor property                                                               // 44
                                                                                                                       // 45
        /**                                                                                                            // 46
         * @cfg {Boolean} outputMarkdown                                                                               // 47
         *                                                                                                             // 48
         * `true` if the should be output as markdown instead of html                                                  // 49
         */                                                                                                            // 50
        outputMarkdown : false,                                                                                        // 51
		/**                                                                                                                  // 52
		 * @cfg {Boolean} newWindow                                                                                          // 53
		 *                                                                                                                   // 54
		 * `true` if the links should open in a new window, `false` otherwise.                                               // 55
		 */                                                                                                                  // 56
		newWindow : true,                                                                                                    // 57
                                                                                                                       // 58
		/**                                                                                                                  // 59
		 * @cfg {Boolean} stripPrefix                                                                                        // 60
		 *                                                                                                                   // 61
		 * `true` if 'http://' or 'https://' and/or the 'www.' should be stripped from the beginning of links, `false` otherwise.
		 */                                                                                                                  // 63
		stripPrefix : true,                                                                                                  // 64
                                                                                                                       // 65
		/**                                                                                                                  // 66
		 * @cfg {Number} truncate                                                                                            // 67
		 *                                                                                                                   // 68
		 * A number for how many characters long URLs/emails/twitter handles should be truncated to inside the text of       // 69
		 * a link. If the URL/email/twitter is over this number of characters, it will be truncated to this length by        // 70
		 * adding a two period ellipsis ('..') into the middle of the string.                                                // 71
		 *                                                                                                                   // 72
		 * For example: A url like 'http://www.yahoo.com/some/long/path/to/a/file' truncated to 25 characters might look     // 73
		 * something like this: 'http://www...th/to/a/file'                                                                  // 74
		 */                                                                                                                  // 75
                                                                                                                       // 76
		/**                                                                                                                  // 77
		 * @cfg {Boolean} twitter                                                                                            // 78
		 *                                                                                                                   // 79
		 * `true` if Twitter handles ("@example") should be automatically linked, `false` if they should not be.             // 80
		 */                                                                                                                  // 81
		twitter : true,                                                                                                      // 82
                                                                                                                       // 83
		/**                                                                                                                  // 84
		 * @cfg {Boolean} email                                                                                              // 85
		 *                                                                                                                   // 86
		 * `true` if email addresses should be automatically linked, `false` if they should not be.                          // 87
		 */                                                                                                                  // 88
		email : true,                                                                                                        // 89
                                                                                                                       // 90
		/**                                                                                                                  // 91
		 * @cfg {Boolean} urls                                                                                               // 92
		 *                                                                                                                   // 93
		 * `true` if miscellaneous URLs should be automatically linked, `false` if they should not be.                       // 94
		 */                                                                                                                  // 95
		urls : true,                                                                                                         // 96
                                                                                                                       // 97
		/**                                                                                                                  // 98
		 * @cfg {String} className                                                                                           // 99
		 *                                                                                                                   // 100
		 * A CSS class name to add to the generated links. This class will be added to all links, as well as this class      // 101
		 * plus url/email/twitter suffixes for styling url/email/twitter links differently.                                  // 102
		 *                                                                                                                   // 103
		 * For example, if this config is provided as "myLink", then:                                                        // 104
		 *                                                                                                                   // 105
		 * 1) URL links will have the CSS classes: "myLink myLink-url"                                                       // 106
		 * 2) Email links will have the CSS classes: "myLink myLink-email", and                                              // 107
		 * 3) Twitter links will have the CSS classes: "myLink myLink-twitter"                                               // 108
		 */                                                                                                                  // 109
		className : "",                                                                                                      // 110
                                                                                                                       // 111
                                                                                                                       // 112
		/**                                                                                                                  // 113
		 * @private                                                                                                          // 114
		 * @property {RegExp} matcherRegex                                                                                   // 115
		 *                                                                                                                   // 116
		 * The regular expression that matches URLs, email addresses, and Twitter handles.                                   // 117
		 *                                                                                                                   // 118
		 * This regular expression has the following capturing groups:                                                       // 119
		 *                                                                                                                   // 120
		 * 1. Group that is used to determine if there is a Twitter handle match (i.e. @someTwitterUser). Simply check for its
		 *    existence to determine if there is a Twitter handle match. The next couple of capturing groups give information
		 *    about the Twitter handle match.                                                                                // 123
		 * 2. The whitespace character before the @sign in a Twitter handle. This is needed because there are no lookbehinds in
		 *    JS regular expressions, and can be used to reconstruct the original string in a replace().                     // 125
		 * 3. The Twitter handle itself in a Twitter match. If the match is '@someTwitterUser', the handle is 'someTwitterUser'.
		 * 4. Group that matches an email address. Used to determine if the match is an email address, as well as holding the full
		 *    address. Ex: 'me@my.com'                                                                                       // 128
		 * 5. Group that matches a URL in the input text. Ex: 'http://google.com', 'www.google.com', or just 'google.com'.   // 129
		 *    This also includes a path, url parameters, or hash anchors. Ex: google.com/path/to/file?q1=1&q2=2#myAnchor     // 130
		 * 6. A protocol-relative ('//') match for the case of a 'www.' prefixed URL. Will be an empty string if it is not a // 131
		 *    protocol-relative match. We need to know the character before the '//' in order to determine if it is a valid match
		 *    or the // was in a string we don't want to auto-link.                                                          // 133
		 * 7. A protocol-relative ('//') match for the case of a known TLD prefixed URL. Will be an empty string if it is not a
		 *    protocol-relative match. See #6 for more info.                                                                 // 135
		 */                                                                                                                  // 136
		matcherRegex : (function() {                                                                                         // 137
			var twitterRegex = /(^|[^\w])@(\w{1,15})/,              // For matching a twitter handle. Ex: @gregory_jacobs       // 138
                                                                                                                       // 139
			    emailRegex = /(?:[\-;:&=\+\$,\w\.]+@)/,             // something@ for email addresses (a.k.a. local-part)       // 140
                                                                                                                       // 141
			    protocolRegex = /(?:[A-Za-z]{3,9}:(?:\/\/)?)/,      // match protocol, allow in format http:// or mailto:       // 142
			    wwwRegex = /(?:www\.)/,                             // starting with 'www.'                                     // 143
			    domainNameRegex = /[A-Za-z0-9\.\-]*[A-Za-z0-9\-]/,  // anything looking at all like a domain, non-unicode domains, not ending in a period
			    tldRegex = /\.(?:international|construction|contractors|enterprises|photography|productions|foundation|immobilien|industries|management|properties|technology|christmas|community|directory|education|equipment|institute|marketing|solutions|vacations|bargains|boutique|builders|catering|cleaning|clothing|computer|democrat|diamonds|graphics|holdings|lighting|partners|plumbing|supplies|training|ventures|academy|careers|company|cruises|domains|exposed|flights|florist|gallery|guitars|holiday|kitchen|neustar|okinawa|recipes|rentals|reviews|shiksha|singles|support|systems|agency|berlin|camera|center|coffee|condos|dating|estate|events|expert|futbol|kaufen|luxury|maison|monash|museum|nagoya|photos|repair|report|social|supply|tattoo|tienda|travel|viajes|villas|vision|voting|voyage|actor|build|cards|cheap|codes|dance|email|glass|house|mango|ninja|parts|photo|shoes|solar|today|tokyo|tools|watch|works|aero|arpa|asia|best|bike|blue|buzz|camp|club|cool|coop|farm|fish|gift|guru|info|jobs|kiwi|kred|land|limo|link|menu|mobi|moda|name|pics|pink|post|qpon|rich|ruhr|sexy|tips|vote|voto|wang|wien|wiki|zone|bar|bid|biz|cab|cat|ceo|com|edu|gov|int|kim|mil|net|onl|org|pro|pub|red|tel|uno|wed|xxx|xyz|ac|ad|ae|af|ag|ai|al|am|an|ao|aq|ar|as|at|au|aw|ax|az|ba|bb|bd|be|bf|bg|bh|bi|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|cr|cu|cv|cw|cx|cy|cz|de|dj|dk|dm|do|dz|ec|ee|eg|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|im|in|io|iq|ir|is|it|je|jm|jo|jp|ke|kg|kh|ki|km|kn|kp|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mh|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|mv|mw|mx|my|mz|na|nc|ne|nf|ng|ni|nl|no|np|nr|nu|nz|om|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|ps|pt|pw|py|qa|re|ro|rs|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sx|sy|sz|tc|td|tf|tg|th|tj|tk|tl|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|za|zm|zw)\b/,   // match our known top level domains (TLDs)
                                                                                                                       // 146
			    // Allow optional path, query string, and hash anchor, not ending in the following characters: "!:,.;"          // 147
			    // http://blog.codinghorror.com/the-problem-with-urls/                                                          // 148
			    urlSuffixRegex = /(?:[\-A-Za-z0-9+&@#\/%?=~_()|!:,.;]*[\-A-Za-z0-9+&@#\/%=~_()|])?/;  // note: optional part of the full regex
                                                                                                                       // 150
			return new RegExp( [                                                                                                // 151
				'(',  // *** Capturing group $1, which can be used to check for a twitter handle match. Use group $3 for the actual twitter handle though. $2 may be used to reconstruct the original string in a replace()
					// *** Capturing group $2, which matches the whitespace character before the '@' sign (needed because of no lookbehinds), and
					// *** Capturing group $3, which matches the actual twitter handle                                                // 154
					twitterRegex.source,                                                                                              // 155
				')',                                                                                                               // 156
                                                                                                                       // 157
				'|',                                                                                                               // 158
                                                                                                                       // 159
				'(',  // *** Capturing group $4, which is used to determine an email match                                         // 160
					emailRegex.source,                                                                                                // 161
					domainNameRegex.source,                                                                                           // 162
					tldRegex.source,                                                                                                  // 163
				')',                                                                                                               // 164
                                                                                                                       // 165
				'|',                                                                                                               // 166
                                                                                                                       // 167
				'(',  // *** Capturing group $5, which is used to match a URL                                                      // 168
					'(?:', // parens to cover match for protocol (optional), and domain                                               // 169
						'(?:',  // non-capturing paren for a protocol-prefixed url (ex: http://google.com)                               // 170
							protocolRegex.source,                                                                                           // 171
							domainNameRegex.source,                                                                                         // 172
						')',                                                                                                             // 173
                                                                                                                       // 174
						'|',                                                                                                             // 175
                                                                                                                       // 176
						'(?:',  // non-capturing paren for a 'www.' prefixed url (ex: www.google.com)                                    // 177
							'(.?//)?',  // *** Capturing group $6 for an optional protocol-relative URL. Must be at the beginning of the string or start with a non-word character
							wwwRegex.source,                                                                                                // 179
							domainNameRegex.source,                                                                                         // 180
						')',                                                                                                             // 181
                                                                                                                       // 182
						'|',                                                                                                             // 183
                                                                                                                       // 184
						'(?:',  // non-capturing paren for known a TLD url (ex: google.com)                                              // 185
							'(.?//)?',  // *** Capturing group $7 for an optional protocol-relative URL. Must be at the beginning of the string or start with a non-word character
							domainNameRegex.source,                                                                                         // 187
							tldRegex.source,                                                                                                // 188
						')',                                                                                                             // 189
					')',                                                                                                              // 190
                                                                                                                       // 191
					urlSuffixRegex.source,  // match for path, query string, and/or hash anchor                                       // 192
				')'                                                                                                                // 193
			].join( "" ), 'gi' );                                                                                               // 194
		} )(),                                                                                                               // 195
                                                                                                                       // 196
		/**                                                                                                                  // 197
		 * @private                                                                                                          // 198
		 * @property {RegExp} protocolRelativeRegex                                                                          // 199
		 *                                                                                                                   // 200
		 * The regular expression used to find protocol-relative URLs. A protocol-relative URL is, for example, "//yahoo.com"
		 *                                                                                                                   // 202
		 * This regular expression needs to match the character before the '//', in order to determine if we should actually // 203
		 * autolink a protocol-relative URL. For instance, we want to autolink something like "//google.com", but we         // 204
		 * don't want to autolink something like "abc//google.com"                                                           // 205
		 */                                                                                                                  // 206
		protocolRelativeRegex : /(.)?\/\//,                                                                                  // 207
                                                                                                                       // 208
		/**                                                                                                                  // 209
		 * @private                                                                                                          // 210
		 * @property {RegExp} htmlRegex                                                                                      // 211
		 *                                                                                                                   // 212
		 * The regular expression used to pull out HTML tags from a string. Handles namespaced HTML tags and                 // 213
		 * attribute names, as specified by http://www.w3.org/TR/html-markup/syntax.html.                                    // 214
		 *                                                                                                                   // 215
		 * Capturing groups:                                                                                                 // 216
		 *                                                                                                                   // 217
		 * 1. If it is an end tag, this group will have the '/'.                                                             // 218
		 * 2. The tag name.                                                                                                  // 219
		 */                                                                                                                  // 220
		htmlRegex : (function() {                                                                                            // 221
			var tagNameRegex = /[0-9a-zA-Z:]+/,                                                                                 // 222
			    attrNameRegex = /[^\s\0"'>\/=\x01-\x1F\x7F]+/,   // the unicode range accounts for excluding control chars, and the delete char
			    attrValueRegex = /(?:".*?"|'.*?'|[^'"=<>`\s]+)/; // double quoted, single quoted, or unquoted attribute values  // 224
                                                                                                                       // 225
			return new RegExp( [                                                                                                // 226
				'<(/)?',  // Beginning of a tag. Either '<' for a start tag, or '</' for an end tag. The slash or an empty string is Capturing Group 1.
                                                                                                                       // 228
					// The tag name (Capturing Group 2)                                                                               // 229
					'(' + tagNameRegex.source + ')',                                                                                  // 230
                                                                                                                       // 231
					// Zero or more attributes following the tag name                                                                 // 232
					'(?:',                                                                                                            // 233
						'\\s+',  // one or more whitespace chars before an attribute                                                     // 234
						attrNameRegex.source,                                                                                            // 235
						'(?:\\s*=\\s*' + attrValueRegex.source + ')?',  // optional '=[value]'                                           // 236
					')*',                                                                                                             // 237
                                                                                                                       // 238
					'\\s*/?',  // any trailing spaces and optional '/' before the closing '>'                                         // 239
				'>'                                                                                                                // 240
			].join( "" ), 'g' );                                                                                                // 241
		} )(),                                                                                                               // 242
                                                                                                                       // 243
		/**                                                                                                                  // 244
		 * @private                                                                                                          // 245
		 * @property {RegExp} urlPrefixRegex                                                                                 // 246
		 *                                                                                                                   // 247
		 * A regular expression used to remove the 'http://' or 'https://' and/or the 'www.' from URLs.                      // 248
		 */                                                                                                                  // 249
		urlPrefixRegex: /^(https?:\/\/)?(www\.)?/i,                                                                          // 250
                                                                                                                       // 251
                                                                                                                       // 252
		/**                                                                                                                  // 253
		 * Automatically links URLs, email addresses, and Twitter handles found in the given chunk of HTML.                  // 254
		 * Does not link URLs found within HTML tags.                                                                        // 255
		 *                                                                                                                   // 256
		 * For instance, if given the text: `You should go to http://www.yahoo.com`, then the result                         // 257
		 * will be `You should go to &lt;a href="http://www.yahoo.com"&gt;http://www.yahoo.com&lt;/a&gt;`                    // 258
		 *                                                                                                                   // 259
		 * @method link                                                                                                      // 260
		 * @param {String} textOrHtml The HTML or text to link URLs, email addresses, and Twitter handles within.            // 261
		 * @return {String} The HTML, with URLs/emails/twitter handles automatically linked.                                 // 262
		 */                                                                                                                  // 263
		link : function( textOrHtml ) {                                                                                      // 264
			return this.processHtml( textOrHtml );                                                                              // 265
		},                                                                                                                   // 266
                                                                                                                       // 267
                                                                                                                       // 268
		/**                                                                                                                  // 269
		 * Processes the given HTML to auto-link URLs/emails/Twitter handles.                                                // 270
		 *                                                                                                                   // 271
		 * Finds the text around any HTML elements in the input `html`, which will be the text that is processed.            // 272
		 * Any original HTML elements will be left as-is, as well as the text that is already wrapped in anchor tags.        // 273
		 *                                                                                                                   // 274
		 * @private                                                                                                          // 275
		 * @method processHtml                                                                                               // 276
		 * @param {String} html The input text or HTML to process in order to auto-link.                                     // 277
		 * @return {String}                                                                                                  // 278
		 */                                                                                                                  // 279
		processHtml : function( html ) {                                                                                     // 280
			// Loop over the HTML string, ignoring HTML tags, and processing the text that lies between them,                   // 281
			// wrapping the URLs in anchor tags                                                                                 // 282
			var htmlRegex = this.htmlRegex,                                                                                     // 283
			    currentResult,                                                                                                  // 284
			    inBetweenTagsText,                                                                                              // 285
			    lastIndex = 0,                                                                                                  // 286
			    anchorTagStackCount = 0,                                                                                        // 287
			    resultHtml = [];                                                                                                // 288
                                                                                                                       // 289
			while( ( currentResult = htmlRegex.exec( html ) ) !== null ) {                                                      // 290
				var tagText = currentResult[ 0 ],                                                                                  // 291
				    tagName = currentResult[ 2 ],                                                                                  // 292
				    isClosingTag = !!currentResult[ 1 ];                                                                           // 293
                                                                                                                       // 294
				inBetweenTagsText = html.substring( lastIndex, currentResult.index );                                              // 295
				lastIndex = currentResult.index + tagText.length;                                                                  // 296
                                                                                                                       // 297
				// Process around anchor tags, and any inner text / html they may have                                             // 298
				if( tagName === 'a' ) {                                                                                            // 299
					if( !isClosingTag ) {  // it's the start <a> tag                                                                  // 300
						anchorTagStackCount++;                                                                                           // 301
						resultHtml.push( this.processTextNode( inBetweenTagsText ) );                                                    // 302
                                                                                                                       // 303
					} else {   // it's the end </a> tag                                                                               // 304
						anchorTagStackCount = Math.max( anchorTagStackCount - 1, 0 );  // attempt to handle extraneous </a> tags by making sure the stack count never goes below 0
						if( anchorTagStackCount === 0 ) {                                                                                // 306
							resultHtml.push( inBetweenTagsText );  // We hit the matching </a> tag, simply add all of the text from the start <a> tag to the end </a> tag without linking it
						}                                                                                                                // 308
					}                                                                                                                 // 309
                                                                                                                       // 310
				} else if( anchorTagStackCount === 0 ) {   // not within an anchor tag, link the "in between" text                 // 311
					resultHtml.push( this.processTextNode( inBetweenTagsText ) );                                                     // 312
                                                                                                                       // 313
				} else {                                                                                                           // 314
					// if we have a tag that is in between anchor tags (ex: <a href="..."><b>google.com</b></a>),                     // 315
					// just append the inner text                                                                                     // 316
					resultHtml.push( inBetweenTagsText );                                                                             // 317
				}                                                                                                                  // 318
                                                                                                                       // 319
				resultHtml.push( tagText );  // now add the text of the tag itself verbatim                                        // 320
			}                                                                                                                   // 321
                                                                                                                       // 322
			// Process any remaining text after the last HTML element. Will process all of the text if there were no HTML elements.
			if( lastIndex < html.length ) {                                                                                     // 324
				var processedTextNode = this.processTextNode( html.substring( lastIndex ) );                                       // 325
				resultHtml.push( processedTextNode );                                                                              // 326
			}                                                                                                                   // 327
                                                                                                                       // 328
			return resultHtml.join( "" );                                                                                       // 329
		},                                                                                                                   // 330
                                                                                                                       // 331
                                                                                                                       // 332
		/**                                                                                                                  // 333
		 * Process the text that lies inbetween HTML tags. This method does the actual wrapping of URLs with                 // 334
		 * anchor tags.                                                                                                      // 335
		 *                                                                                                                   // 336
		 * @private                                                                                                          // 337
		 * @param {String} text The text to auto-link.                                                                       // 338
		 * @return {String} The text with anchor tags auto-filled.                                                           // 339
		 */                                                                                                                  // 340
		processTextNode : function( text ) {                                                                                 // 341
			var me = this,  // for closures                                                                                     // 342
			    matcherRegex = this.matcherRegex,                                                                               // 343
			    enableTwitter = this.twitter,                                                                                   // 344
			    enableEmailAddresses = this.email,                                                                              // 345
			    enableUrls = this.urls;                                                                                         // 346
                                                                                                                       // 347
			return text.replace( matcherRegex, function( matchStr, $1, $2, $3, $4, $5, $6, $7 ) {                               // 348
				var twitterMatch = $1,                                                                                             // 349
				    twitterHandlePrefixWhitespaceChar = $2,  // The whitespace char before the @ sign in a Twitter handle match. This is needed because of no lookbehinds in JS regexes
				    twitterHandle = $3,   // The actual twitterUser (i.e the word after the @ sign in a Twitter handle match)      // 351
				    emailAddress = $4,    // For both determining if it is an email address, and stores the actual email address   // 352
				    urlMatch = $5,        // The matched URL string                                                                // 353
				    protocolRelativeMatch = $6 || $7,  // The '//' for a protocol-relative match, with the character that comes before the '//'
                                                                                                                       // 355
				    prefixStr = "",       // A string to use to prefix the anchor tag that is created. This is needed for the Twitter handle match
				    suffixStr = "";       // A string to suffix the anchor tag that is created. This is used if there is a trailing parenthesis that should not be auto-linked.
                                                                                                                       // 358
				// Early exits with no replacements for:                                                                           // 359
				// 1) Disabled link types                                                                                          // 360
				// 2) URL matches which do not have at least have one period ('.') in the domain name (effectively skipping over   // 361
				//    matches like "abc:def")                                                                                      // 362
				// 3) A protocol-relative url match (a URL beginning with '//') whose previous character is a word character       // 363
				//    (effectively skipping over strings like "abc//google.com")                                                   // 364
				if(                                                                                                                // 365
				    ( twitterMatch && !enableTwitter ) || ( emailAddress && !enableEmailAddresses ) || ( urlMatch && !enableUrls ) ||
				    ( urlMatch && urlMatch.indexOf( '.' ) === -1 ) ||  // At least one period ('.') must exist in the URL match for us to consider it an actual URL
				    ( urlMatch && /^[A-Za-z]{3,9}:/.test( urlMatch ) && !/:.*?[A-Za-z]/.test( urlMatch ) ) ||  // At least one letter character must exist in the domain name after a protocol match. Ex: skip over something like "git:1.0"
				    ( protocolRelativeMatch && /^[\w]\/\//.test( protocolRelativeMatch ) )  // a protocol-relative match which has a word character in front of it (so we can skip something like "abc//google.com")
				) {                                                                                                                // 370
					return matchStr;                                                                                                  // 371
				}                                                                                                                  // 372
                                                                                                                       // 373
                                                                                                                       // 374
				// Handle a closing parenthesis at the end of the match, and exclude it if there is not a matching open parenthesis
				// in the match. This handles cases like the string "wikipedia.com/something_(disambiguation)" (which should be auto-
				// linked, and when it is enclosed in parenthesis itself, such as: "(wikipedia.com/something_(disambiguation))" (in
				// which the outer parens should *not* be auto-linked.                                                             // 378
				var lastChar = matchStr.charAt( matchStr.length - 1 );                                                             // 379
				if( lastChar === ')' ) {                                                                                           // 380
					var openParensMatch = matchStr.match( /\(/g ),                                                                    // 381
					    closeParensMatch = matchStr.match( /\)/g ),                                                                   // 382
					    numOpenParens = ( openParensMatch && openParensMatch.length ) || 0,                                           // 383
					    numCloseParens = ( closeParensMatch && closeParensMatch.length ) || 0;                                        // 384
                                                                                                                       // 385
					if( numOpenParens < numCloseParens ) {                                                                            // 386
						matchStr = matchStr.substr( 0, matchStr.length - 1 );  // remove the trailing ")"                                // 387
						suffixStr = ")";  // this will be added after the <a> tag                                                        // 388
					}                                                                                                                 // 389
				}                                                                                                                  // 390
                                                                                                                       // 391
                                                                                                                       // 392
				var anchorHref = matchStr,  // initialize both of these                                                            // 393
				    anchorText = matchStr,  // values as the full match                                                            // 394
				    linkType;                                                                                                      // 395
                                                                                                                       // 396
				// Process the urls that are found. We need to change URLs like "www.yahoo.com" to "http://www.yahoo.com" (or the browser
				// will try to direct the user to "http://current-domain.com/www.yahoo.com"), and we need to prefix 'mailto:' to email addresses.
				if( twitterMatch ) {                                                                                               // 399
					linkType = 'twitter';                                                                                             // 400
					prefixStr = twitterHandlePrefixWhitespaceChar;                                                                    // 401
					anchorHref = 'https://twitter.com/' + twitterHandle;                                                              // 402
					anchorText = '@' + twitterHandle;                                                                                 // 403
                                                                                                                       // 404
				} else if( emailAddress ) {                                                                                        // 405
					linkType = 'email';                                                                                               // 406
					anchorHref = 'mailto:' + emailAddress;                                                                            // 407
					anchorText = emailAddress;                                                                                        // 408
                                                                                                                       // 409
				} else {  // url match                                                                                             // 410
					linkType = 'url';                                                                                                 // 411
                                                                                                                       // 412
					if( protocolRelativeMatch ) {                                                                                     // 413
						// Strip off any protocol-relative '//' from the anchor text (leaving the previous non-word character            // 414
						// intact, if there is one)                                                                                      // 415
						var protocolRelRegex = new RegExp( "^" + me.protocolRelativeRegex.source ),  // for this one, we want to only match at the beginning of the string
						    charBeforeMatch = protocolRelativeMatch.match( protocolRelRegex )[ 1 ] || "";                                // 417
                                                                                                                       // 418
						prefixStr = charBeforeMatch + prefixStr;  // re-add the character before the '//' to what will be placed before the <a> tag
						anchorHref = anchorHref.replace( protocolRelRegex, "//" );  // remove the char before the match for the href     // 420
						anchorText = anchorText.replace( protocolRelRegex, "" );    // remove both the char before the match and the '//' for the anchor text
                                                                                                                       // 422
					} else if( !/^[A-Za-z]{3,9}:/i.test( anchorHref ) ) {                                                             // 423
						// url string doesn't begin with a protocol, assume http://                                                      // 424
						anchorHref = 'http://' + anchorHref;                                                                             // 425
					}                                                                                                                 // 426
				}                                                                                                                  // 427
                                                                                                                       // 428
				// wrap the match in an anchor tag                                                                                 // 429
				var anchorTag = me.createAnchorTag( linkType, anchorHref, anchorText );                                            // 430
				return prefixStr + anchorTag + suffixStr;                                                                          // 431
			} );                                                                                                                // 432
		},                                                                                                                   // 433
                                                                                                                       // 434
                                                                                                                       // 435
		/**                                                                                                                  // 436
		 * Generates the actual anchor (&lt;a&gt;) tag to use in place of a source url/email/twitter link.                   // 437
		 *                                                                                                                   // 438
		 * @private                                                                                                          // 439
		 * @param {"url"/"email"/"twitter"} linkType The type of link that an anchor tag is being generated for.             // 440
		 * @param {String} anchorHref The href for the anchor tag.                                                           // 441
		 * @param {String} anchorText The anchor tag's text (i.e. what will be displayed).                                   // 442
		 * @return {String} The full HTML for the anchor tag.                                                                // 443
		 */                                                                                                                  // 444
		createAnchorTag : function( linkType, anchorHref, anchorText ) {                                                     // 445
            var me = this; //for closures                                                                              // 446
			var attributesStr = this.createAnchorAttrsStr( linkType, anchorHref );                                              // 447
			anchorText = this.processAnchorText( anchorText );                                                                  // 448
                                                                                                                       // 449
            if(me.outputMarkdown){                                                                                     // 450
                return "!["+anchorText+"]("+anchorHref+")";                                                            // 451
            }else{                                                                                                     // 452
    			return '<a ' + attributesStr + '>' + anchorText + '</a>';                                                       // 453
            }                                                                                                          // 454
		},                                                                                                                   // 455
                                                                                                                       // 456
                                                                                                                       // 457
		/**                                                                                                                  // 458
		 * Creates the string which will be the HTML attributes for the anchor (&lt;a&gt;) tag being generated.              // 459
		 *                                                                                                                   // 460
		 * @private                                                                                                          // 461
		 * @param {"url"/"email"/"twitter"} linkType The type of link that an anchor tag is being generated for.             // 462
		 * @param {String} href The href for the anchor tag.                                                                 // 463
		 * @return {String} The anchor tag's attribute. Ex: `href="http://google.com" class="myLink myLink-url" target="_blank"`
		 */                                                                                                                  // 465
		createAnchorAttrsStr : function( linkType, anchorHref ) {                                                            // 466
			var attrs = [ 'href="' + anchorHref + '"' ];  // we'll always have the `href` attribute                             // 467
                                                                                                                       // 468
			var cssClass = this.createCssClass( linkType );                                                                     // 469
			if( cssClass ) {                                                                                                    // 470
				attrs.push( 'class="' + cssClass + '"' );                                                                          // 471
			}                                                                                                                   // 472
			if( this.newWindow ) {                                                                                              // 473
				attrs.push( 'target="_blank"' );                                                                                   // 474
			}                                                                                                                   // 475
                                                                                                                       // 476
			return attrs.join( " " );                                                                                           // 477
		},                                                                                                                   // 478
                                                                                                                       // 479
                                                                                                                       // 480
		/**                                                                                                                  // 481
		 * Creates the CSS class that will be used for a given anchor tag, based on the `linkType` and the {@link #className}
		 * config.                                                                                                           // 483
		 *                                                                                                                   // 484
		 * @private                                                                                                          // 485
		 * @param {"url"/"email"/"twitter"} linkType The type of link that an anchor tag is being generated for.             // 486
		 * @return {String} The CSS class string for the link. Example return: "myLink myLink-url". If no {@link #className} // 487
		 *   was configured, returns an empty string.                                                                        // 488
		 */                                                                                                                  // 489
		createCssClass : function( linkType ) {                                                                              // 490
			var className = this.className;                                                                                     // 491
                                                                                                                       // 492
			if( !className )                                                                                                    // 493
				return "";                                                                                                         // 494
			else                                                                                                                // 495
				return className + " " + className + "-" + linkType;  // ex: "myLink myLink-url", "myLink myLink-email", or "myLink myLink-twitter"
		},                                                                                                                   // 497
                                                                                                                       // 498
                                                                                                                       // 499
		/**                                                                                                                  // 500
		 * Processes the `anchorText` by stripping the URL prefix (if {@link #stripPrefix} is `true`), removing              // 501
		 * any trailing slash, and truncating the text according to the {@link #truncate} config.                            // 502
		 *                                                                                                                   // 503
		 * @private                                                                                                          // 504
		 * @param {String} anchorText The anchor tag's text (i.e. what will be displayed).                                   // 505
		 * @return {String} The processed `anchorText`.                                                                      // 506
		 */                                                                                                                  // 507
		processAnchorText : function( anchorText ) {                                                                         // 508
			if( this.stripPrefix ) {                                                                                            // 509
				anchorText = this.stripUrlPrefix( anchorText );                                                                    // 510
			}                                                                                                                   // 511
			anchorText = this.removeTrailingSlash( anchorText );  // remove trailing slash, if there is one                     // 512
			anchorText = this.doTruncate( anchorText );                                                                         // 513
                                                                                                                       // 514
			return anchorText;                                                                                                  // 515
		},                                                                                                                   // 516
                                                                                                                       // 517
                                                                                                                       // 518
		/**                                                                                                                  // 519
		 * Strips the URL prefix (such as "http://" or "https://") from the given text.                                      // 520
		 *                                                                                                                   // 521
		 * @private                                                                                                          // 522
		 * @param {String} text The text of the anchor that is being generated, for which to strip off the                   // 523
		 *   url prefix (such as stripping off "http://")                                                                    // 524
		 * @return {String} The `anchorText`, with the prefix stripped.                                                      // 525
		 */                                                                                                                  // 526
		stripUrlPrefix : function( text ) {                                                                                  // 527
			return text.replace( this.urlPrefixRegex, '' );                                                                     // 528
		},                                                                                                                   // 529
                                                                                                                       // 530
                                                                                                                       // 531
		/**                                                                                                                  // 532
		 * Removes any trailing slash from the given `anchorText`, in prepration for the text to be displayed.               // 533
		 *                                                                                                                   // 534
		 * @private                                                                                                          // 535
		 * @param {String} anchorText The text of the anchor that is being generated, for which to remove any trailing       // 536
		 *   slash ('/') that may exist.                                                                                     // 537
		 * @return {String} The `anchorText`, with the trailing slash removed.                                               // 538
		 */                                                                                                                  // 539
		removeTrailingSlash : function( anchorText ) {                                                                       // 540
			if( anchorText.charAt( anchorText.length - 1 ) === '/' ) {                                                          // 541
				anchorText = anchorText.slice( 0, -1 );                                                                            // 542
			}                                                                                                                   // 543
			return anchorText;                                                                                                  // 544
		},                                                                                                                   // 545
                                                                                                                       // 546
                                                                                                                       // 547
		/**                                                                                                                  // 548
		 * Performs the truncation of the `anchorText`, if the `anchorText` is longer than the {@link #truncate} option.     // 549
		 * Truncates the text to 2 characters fewer than the {@link #truncate} option, and adds ".." to the end.             // 550
		 *                                                                                                                   // 551
		 * @private                                                                                                          // 552
		 * @param {String} text The anchor tag's text (i.e. what will be displayed).                                         // 553
		 * @return {String} The truncated anchor text.                                                                       // 554
		 */                                                                                                                  // 555
		doTruncate : function( anchorText ) {                                                                                // 556
			var truncateLen = this.truncate;                                                                                    // 557
                                                                                                                       // 558
			// Truncate the anchor text if it is longer than the provided 'truncate' option                                     // 559
			if( truncateLen && anchorText.length > truncateLen ) {                                                              // 560
				anchorText = anchorText.substring( 0, truncateLen - 2 ) + '..';                                                    // 561
			}                                                                                                                   // 562
			return anchorText;                                                                                                  // 563
		}                                                                                                                    // 564
                                                                                                                       // 565
	};                                                                                                                    // 566
                                                                                                                       // 567
                                                                                                                       // 568
	/**                                                                                                                   // 569
	 * Automatically links URLs, email addresses, and Twitter handles found in the given chunk of HTML.                   // 570
	 * Does not link URLs found within HTML tags.                                                                         // 571
	 *                                                                                                                    // 572
	 * For instance, if given the text: `You should go to http://www.yahoo.com`, then the result                          // 573
	 * will be `You should go to &lt;a href="http://www.yahoo.com"&gt;http://www.yahoo.com&lt;/a&gt;`                     // 574
	 *                                                                                                                    // 575
	 * Example:                                                                                                           // 576
	 *                                                                                                                    // 577
	 *     var linkedText = Autolinker.link( "Go to google.com", { newWindow: false } );                                  // 578
	 *     // Produces: "Go to <a href="http://google.com">google.com</a>"                                                // 579
	 *                                                                                                                    // 580
	 * @static                                                                                                            // 581
	 * @method link                                                                                                       // 582
	 * @param {String} html The HTML text to link URLs within.                                                            // 583
	 * @param {Object} [options] Any of the configuration options for the Autolinker class, specified in an Object (map). // 584
	 *   See the class description for an example call.                                                                   // 585
	 * @return {String} The HTML text, with URLs automatically linked                                                     // 586
	 */                                                                                                                   // 587
	Autolinker.link = function( text, options ) {                                                                         // 588
		var autolinker = new Autolinker( options );                                                                          // 589
		return autolinker.link( text );                                                                                      // 590
	};                                                                                                                    // 591
                                                                                                                       // 592
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['copleykj:autolinker'] = {
  Autolinker: Autolinker
};

})();

//# sourceMappingURL=copleykj_autolinker.js.map
