(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['richsilv:pikaday'] = {};

})();

//# sourceMappingURL=richsilv_pikaday.js.map
